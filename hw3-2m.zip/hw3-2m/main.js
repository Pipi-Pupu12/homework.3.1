let hasTicket = true;
let hasPassport = false;
let money = 1000;

if (hasTicket && hasPassport) {
    console.log("Можно лететь на самолете");
} else if (money > 100) {
    console.log("Можно поехать на автобусе");
} else {
    console.log("Остаёмся дома");
}